# AWS Lambda Deployment Guide

## Prerequisites
1. AWS CLI configured with appropriate permissions
2. Node.js 18+ installed
3. MongoDB Atlas database (recommended for Lambda)

## Setup Steps

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env` and update with your values:
```bash
cp .env.example .env
```

### 3. Test Locally
```bash
npm run offline
```

### 4. Deploy to AWS
```bash
# Deploy to dev stage
npm run deploy

# Deploy to production
npm run deploy:prod
```

## Environment Variables Required
- `MONGODB_URI`: MongoDB connection string (use MongoDB Atlas)
- `JWT_SECRET`: Secret key for JWT tokens
- `CLOUDINARY_*`: Cloudinary credentials for image uploads

## Lambda Considerations
- Database connections are reused across invocations
- Cold starts may occur after periods of inactivity
- 30-second timeout configured (adjust if needed)
- CORS enabled for all origins

## API Gateway Endpoints
After deployment, your API will be available at:
```
https://[api-id].execute-api.[region].amazonaws.com/[stage]/api/
```

## Monitoring
- CloudWatch logs available for debugging
- API Gateway metrics for performance monitoring
